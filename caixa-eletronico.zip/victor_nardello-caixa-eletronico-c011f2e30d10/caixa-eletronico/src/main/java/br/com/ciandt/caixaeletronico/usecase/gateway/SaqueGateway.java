package br.com.ciandt.caixaeletronico.usecase.gateway;

import br.com.ciandt.caixaeletronico.usecase.domain.SaqueDomain;

public interface SaqueGateway {
	
	public SaqueDomain getSaqueContaCorrente();

}
